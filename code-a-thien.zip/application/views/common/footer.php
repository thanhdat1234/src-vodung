<div class="center">   
		<span class="white">PHẦN MỀM QUẢN LÝ BÁN HÀNG V 1.5</span>

		<a target="_blank" data-event-category="Manage" data-event-action="support-page"><span class="white"> Hotline: (08) 688 969 44</span></a>
		<span class="white"> COPYRIGHT © POSBASIC</span>
</div>